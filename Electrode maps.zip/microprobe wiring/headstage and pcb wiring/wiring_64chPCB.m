%first column = channel number on probe.

%second column = channel number on the probe PCB connector for the head
%stage, assuming the HS will be plugged in from the top.

%third column = channel number on the probe PCB connector for the head
%stage, assuming the HS will be plugged in from the bottom.


pcbwiring=[

1	64	1
2	63	2
3	62	3
4	61	4
5	60	5
6	59	6
7	58	7
8	57	8
9	56	9
10	55	10
11	54	11
12	53	12
13	52	13
14	51	14
15	50	15
16	49	16
17	48	17
18	47	18
19	46	19
20	45	20
21	44	21
22	43	22
23	42	23
24	41	24
25	40	25
26	39	26
27	38	27
28	37	28
29	36	29
30	35	30
31	34	31
32	33	32
33	32	33
34	31	34
35	30	35
36	29	36
37	28	37
38	27	38
39	26	39
40	25	40
41	24	41
42	23	42
43	22	43
44	21	44
45	20	45
46	19	46
47	18	47
48	17	48
49	16	49
50	15	50
51	14	51
52	13	52
53	12	53
54	11	54
55	10	55
56	9	56
57	8	57
58	7	58
59	6	59
60	5	60
61	4	61
62	3	62
63	2	63
64	1	64


];