Please note:
the top and bottom soldermasks are negative (masks should cover most areas of the board except the filled areas).